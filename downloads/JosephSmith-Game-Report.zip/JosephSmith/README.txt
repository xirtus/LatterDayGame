Joseph Smith Life History and Game Production Report
22 October 2026

Open index.html in a browser or Codex to read the illustrated report.
The report works from local files and does not require a running game server.

Contents
32 chapter treatments covering Joseph's life and an explicitly imaginative
postmortal and celestial continuation; 40 concept panels across five boards;
65 casting and voice-family briefs; working scene dialogue and audition lines;
Celandia reuse and style direction; MOSSlanding workflow; source references;
and the optional xChurch-inspired seven-era Zion campaign.
The character-design addition includes four new character concept sheets,
the complete modeling roster, and a live original/toon material comparison.

Important working files
docs/campaign.json             Chapter dates, history, play, art, and sources
docs/cast.json                 Character voice descriptions and auditions
docs/dialogue.json             Working dialogue beats
docs/sermon-passages.json      Adapted King Follett doctrinal passages
docs/voice-cast.csv            Export for casting and voice preparation
docs/recording-manifest.csv    Export for scene recording and selected takes
docs/sources.json              Source titles, links, and uses
docs/art-prompts.json          Full initial/revision prompts and selected art
docs/character-art-prompts.json  Character sheet prompts and saved user references
docs/modeling-plan.json        Modeling priorities and full cast grouping
docs/modeling-roster.csv       Every voice profile with current model status
docs/meshy-audit.json          Read-only GLB geometry, texture, rig, and clip audit
docs/design.html              Design, theology, engineering, and production prose
docs/template.html            Report presentation and small navigation controls
art/                          Selected project-local concept boards
meshy/                        User-provided source models, preserved unchanged
character-study/index.html    Live original/toon comparison; requires HTTP server
docs/evidence/                Desktop and mobile report captures

Rebuild the report and CSV exports from this directory
python3 tools/build_report.py

Refresh the local model inventory before rebuilding after new Meshy exports
python3 tools/audit_meshy.py

Rebuild the optional 3D comparison with the existing Celandia dependencies
node tools/build_character_study.mjs

The report ZIP excludes the large meshy source folder. The material study uses
that local folder; source models must be present when running it elsewhere.

This is a preproduction report and first-pass script packet, not a playable
game or a recording-locked screenplay. Voices have not been generated or
trained. Concept images are reference proposals, not final game models or
documentary reconstructions. Celandia and MOSSlanding have not been modified.
